
class Produto {
  constructor(id, nome, descricao, preco, categoria, imagem) {
    this.id = id;
    this.nome = nome;
    this.descricao = descricao;
    this.preco = preco;
    this.categoria = categoria;
    this.imagem = imagem;

    this.createdAt = new Date();
    this.updatedAt = new Date();
    this.available = true;
  }

  toJSON() {
    return {
      id: this.id,
      nome: this.nome,
      descricao: this.descricao,
      preco: this.preco,
      categoria: this.categoria,
      imagem: this.imagem,
      createdAt: this.createdAt,
      updatedAt: this.updatedAt,
      available: this.available
    };
  }

  update(dados) {
    if (dados.nome) this.nome = dados.nome;
    if (dados.descricao) this.descricao = dados.descricao;
    if (dados.preco) this.preco = dados.preco;
    if (dados.categoria) this.categoria = dados.categoria;
    if (dados.imagem) this.imagem = dados.imagem;
    if (dados.available !== undefined) this.available = dados.available;

    this.updatedAt = new Date();
  }

  formatarPreco() {
    return `R$ ${this.preco.toFixed(2).replace('.', ',')}`;
  }

  isDisponivel() {
    return this.available === true;
  }
}

module.exports = Produto;

const Product = require('./models/Product');

const paoFrances = new Product(
  1,
  'Pão Francês',
  'Pão fresquinho do dia',
  0.50,
  1,
  'pao-frances.jpg'
);

console.log('Preço bonitinho:', paoFrances.getFormattedPrice());
console.log('Está disponível?', paoFrances.isAvailable());